﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using HelloWorldDAO;

namespace HelloWorldBLNS
{
    public class HelloWorldBL : IHelloWorldBL
    {

        public bool WriteOutputData(string path, OutputData data)
        {
            try
            {
                string format = "";
                format = ObtainOutputFormat(path);
                IOutputDataDao oD = DaoFactory.GetOutputDataDao(format);
                oD.WriteOutputData(data);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public string ObtainOutputFormat(string configFilePath)
        {
            return ObtainOutputFormatfromXML(configFilePath);
        }

        private string ObtainOutputFormatfromXML(string configFilePath)
        {
            string format = "";
            //read xml from path and return value
            if (File.Exists(configFilePath))
            {
                XmlDocument dom = GetXmlDocument(configFilePath);
                foreach (XmlNode node in dom.DocumentElement.ChildNodes)
                {
                    if (node.Name == "OutputFormat")
                    {
                        format = node.InnerText;
                    }
                }
            }
            else
            {
                throw new FileNotFoundException();
            }

            return format;
        }

        private XmlDocument GetXmlDocument(string path)
        {
            using (FileStream xmlFile = new FileStream(path, FileMode.Open))
            {
                XmlDocument dom = new XmlDocument();
                dom.Load(xmlFile);
                return dom;
            }
        }
    }
}
