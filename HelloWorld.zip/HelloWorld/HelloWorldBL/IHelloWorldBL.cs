﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorldDAO;

namespace HelloWorldBLNS
{
    public interface IHelloWorldBL
    {
        bool WriteOutputData(string path, OutputData data);
    }
}
