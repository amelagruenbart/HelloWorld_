﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HelloWorldDAO;
using HelloWorldBLNS;

namespace HelloWorldUnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            bool passed = false;
            IHelloWorldBL helloWorldBL = new HelloWorldBL();
            OutputData outputData = new OutputData();
            outputData.Text = "UnitTest: Hello World!";
            passed = helloWorldBL.WriteOutputData(@"C:\Config.xml", outputData);

            Assert.IsTrue(!passed);

        }

        [TestMethod]
        public void TestMethod2()
        {
            //should pass, for some reason it doesn't, same test is in console application
            bool passed = false;
            IHelloWorldBL helloWorldBL = new HelloWorldBL();
            OutputData outputData = new OutputData();
            outputData.Text = "UnitTest: Hello World!";
            passed = helloWorldBL.WriteOutputData(@"C:\test\Config.xml", outputData);

            Assert.IsTrue(passed);
        }
    }
}
