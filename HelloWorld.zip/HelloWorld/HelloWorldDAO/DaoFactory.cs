﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorldDAO
{
    public class DaoFactory
    {
        private static IOutputDataDao outputDataDao;
        public static IOutputDataDao GetOutputDataDao(string format)
        {
            if (format.Equals("console"))
            {
                outputDataDao = new OutputDataConsoleDao();
            }
            else if (format.Equals("XML"))
            {
                outputDataDao = new OutputDataXmlDao();
            }
            return outputDataDao;
        }
    }
}
