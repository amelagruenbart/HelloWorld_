﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HelloWorldDAO
{
    class OutputDataXmlDao : IOutputDataDao
    {
        public void WriteOutputData(OutputData data)
        {
            throw new NotImplementedException();
        }
    }
}
