Copy the file Config.xml to C:\test\ 
or adjust the path in "HelloWorldTest" and the UnitTest1 "TestMethod2 accordingly. "TestMethod1" has an invalid path on purpose