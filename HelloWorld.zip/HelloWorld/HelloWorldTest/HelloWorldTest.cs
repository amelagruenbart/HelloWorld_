﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HelloWorldBLNS;
using HelloWorldDAO;

namespace HelloWorldTest
{
    class HelloWorldTest
    {
        static void Main(string[] args)
        {
            bool passed = false;
            IHelloWorldBL helloWorldBL = new HelloWorldBL();
            OutputData outputData = new OutputData();
            outputData.Text = "Hello World!";

            passed = helloWorldBL.WriteOutputData(@"C:\test\Config.xml", outputData);
        }
    }
}
